<?php
    $sidebar = App\Http\Controllers\DashboardSidebar::getSidebar();
    $routeName = \Illuminate\Support\Facades\Route::currentRouteName();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Nasmoco Kaligawe - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('vendor/fontawesome-free-5.9.0-web/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('css/sb-admin-2.css')); ?>" rel="stylesheet">

    <!-- DataTables -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/datatables/datatables.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/datatables/FixedColumns-3.2.5/css/fixedColumns.bootstrap4.css')); ?>">

    <!-- DateRangePicker -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/daterangepicker-master/daterangepicker.css')); ?>">

    <!-- Chart JS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/chart.js-2.8.0/Chart.css')); ?>">

    <?php echo $__env->yieldContent('style'); ?>

</head>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <img src="<?php echo e(asset('img/NasmocoKaligawe.png')); ?>" class="img-thumbnail" width="65%" alt="...">




        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <!-- Nav Item - Dashboard -->
        <?php if($routeName == 'dashboard_overview'): ?>
            <li class="nav-item active">
        <?php else: ?>
            <li class="nav-item">
        <?php endif; ?>
            <a class="nav-link" href="<?php echo e(url('dashboard')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Nav Item - Pages Collapse Menu -->
            <?php if(in_array($routeName,$s['group']['url'])): ?>
                <li class="nav-item active">
            <?php else: ?>
                <li class="nav-item">
            <?php endif; ?>
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#<?php echo e($s['group']['id_target']); ?>" aria-expanded="true" aria-controls="<?php echo e($s['group']['id_target']); ?>">
                    <i class="<?php echo e($s['group']['icon']); ?>"></i>
                    <span><?php echo e($s['group']['nama']); ?></span>
                </a>
                <div id="<?php echo e($s['group']['id_target']); ?>" class="collapse" aria-labelledby="<?php echo e($s['group']['id_target']); ?>" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Sub Menu:</h6>
                        <?php $__currentLoopData = $s['menu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="collapse-item" href="<?php echo e(url($m['url'])); ?>"><?php echo e($m['nama']); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                    <li class="nav-item dropdown no-arrow d-sm-none">
                        <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-search fa-fw"></i>
                        </a>
                        <!-- Dropdown - Messages -->
                        <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                            <form class="form-inline mr-auto w-100 navbar-search">
                                <div class="input-group">
                                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="button">
                                            <i class="fas fa-search fa-sm"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </li>

                    <div class="topbar-divider d-none d-sm-block"></div>

                    <!-- Nav Item - User Information -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(\Illuminate\Support\Facades\Session::get('nama_lengkap')); ?></span>
                        </a>
                        <!-- Dropdown - User Information -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">













                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>

            </nav>
            <!-- End of Topbar -->

            <?php if(session('permission')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Permission denied.</strong> <?php echo e(session('permission')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2019</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah anda ingin keluar?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Silahkan klik tombol logout dibawah untuk mengakhiri sesi ini.</div>
            <div class="modal-footer">
                <button class="btn btn-outline-dark" type="button" data-dismiss="modal">Cancel</button>
                <button class="btn btn-danger" type="button" id="btnLogout">Logout</button>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-4.3.1-dist/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- SweetAlert 2 -->
<script src="<?php echo e(asset('vendor/sweetalert2-8.13.1/sweetalert2.all.min.js')); ?>"></script>

<!-- DateRangePicker -->
<script src="<?php echo e(asset('vendor/notify.js/notify.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('js/sb-admin-2.min.js')); ?>"></script>

<!-- DataTables -->
<script type="text/javascript" src="<?php echo e(asset('vendor/datatables/DataTables-1.10.18/js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendor/datatables/DataTables-1.10.18/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendor/datatables/FixedColumns-3.2.5/js/dataTables.fixedColumns.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendor/datatables/FixedColumns-3.2.5/js/fixedColumns.bootstrap4.min.js')); ?>"></script>

<!-- DataTables -->
<script type="text/javascript" src="<?php echo e(asset('vendor/chart.js-2.8.0/Chart.js')); ?>"></script>

<!-- DateRangePicker -->
<script type="text/javascript" src="<?php echo e(asset('vendor/daterangepicker-master/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('vendor/daterangepicker-master/daterangepicker.js')); ?>"></script>

<script type="text/javascript">
    const btnLogout = $('#btnLogout');
    btnLogout.click(function (e) {
        e.preventDefault();
        $.ajax({
            url: "<?php echo e(url('dashboard/logout')); ?>",
            method: "get",
            success: function(result) {
                console.log(result);
                var data = JSON.parse(result);
                if (data.status == 'success') {
                    document.location.replace('<?php echo e(url('dashboard/login')); ?>');
                } else {
                    Swal.fire({
                        type: 'info',
                        title: 'Gagal',
                    });
                }
            }
        });
    })
</script>

<?php echo $__env->yieldContent('script'); ?>

</body>

</html>
<?php /**PATH /home/kevin/Development/nasmoco-kaligawe/resources/views/dashboard-layout.blade.php ENDPATH**/ ?>