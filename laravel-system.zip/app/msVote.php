<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msVote extends Model
{
    protected $table = 'ms_vote';
}
