<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msArea extends Model
{
    protected $table = 'ms_area';
}
