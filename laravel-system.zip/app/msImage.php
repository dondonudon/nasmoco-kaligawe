<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class msImage extends Model
{
    protected $table = 'ms_image';
}
