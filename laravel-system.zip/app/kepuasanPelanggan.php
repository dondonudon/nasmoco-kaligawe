<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kepuasanPelanggan extends Model
{
    protected $table = 'kepuasan_pelanggan';
}
